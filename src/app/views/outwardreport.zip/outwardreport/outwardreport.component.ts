import { Component, OnInit, ViewChild } from "@angular/core";
import { UserService } from "../../services/user.service";
import { NgxSpinnerService } from "ngx-spinner";
import { HttpClient } from "@angular/common/http";
import { Title } from "@angular/platform-browser";
import { DataTableDirective } from "angular-datatables";
import { Subject } from "rxjs";
import { environment } from "../../../environments/environment";
import {
  Validators,
  FormBuilder,
  FormGroup,
  FormControl,
} from "@angular/forms";
import * as XLSX from "xlsx";

class Person {
  Id: number;
  Outlet: string;
  OutwardNumber: string;
  SoNumber: string;
  Category: string;
  SubCategory: string;
  Series: string;
  ArticleNumber: string;
  PartyName: string;
  Quantity: string;
  Rate: string;
  BillAmount: string;
  Discount: string;
  Remarks: string;
  Country: string;
  State: string;
  City: string;
  Pincode: string;
  SalesPerson: string;
}

class DataTablesResponse {
  data: any[];
  draw: number;
  recordsFiltered: number;
  recordsTotal: number;
  startnumber: number;
}

@Component({
  selector: "app-outwardreport",
  templateUrl: "./outwardreport.component.html",
  styleUrls: ["./outwardreport.component.scss"],
})
export class OutwardreportComponent implements OnInit {
  ApiURL: string = environment.apiURL;
  public outwardreportlist: Person[];
  public response: DataTablesResponse[];
  @ViewChild(DataTableDirective)
  dtElement: DataTableDirective;
  dtOptions: any;
  dtTrigger: Subject<any> = new Subject();
  outwardForm: FormGroup;
  isAdd: any;
  isEdit: any;
  isDelete: any;
  isList: any;
  accessdenied: boolean = true;
  public startnumber: any;
  RangeStartDate: Date;
  RangeEndDate: Date;
  OutletPartyId: any;
  public partydropdown: any = [];
  dropdownSettings = {};
  rangeSelected = false;
  allExportRec: any;
  constructor(
    private userService: UserService,
    private formBuilder: FormBuilder,
    private spinner: NgxSpinnerService,
    private http: HttpClient,
    private titleService: Title,
    
  ) {
    this.titleService.setTitle("Outward Report | Colorhunt");
      this.RangeStartDate = new Date();
      this.RangeEndDate = new Date();

  }
  changeOutlet(id){
    if(id == 0){
      this.OutletPartyId = null;
    }
    else{
      this.OutletPartyId = id;
    }
  }
  ngOnInit() {
    let item = JSON.parse(localStorage.getItem("userdata"));
    if (item[0].Role == 2 || item[0].Role == 4) {
      this.accessdenied = false;
    } else {
      this.accessdenied = true;
    }
    this.OutletPartyId = null
    this.userService.outletpartylist().subscribe((res) => {
      this.partydropdown = res;
    });
  }

  onSubmit(data) {
    this.rangeSelected = true;
    if (this.OutletPartyId) {
      const dataUrl =
        this.ApiURL +
        "/outwardoutletreportlist/" +
        data.rangestartdate +
        "/" +
        data.rangeenddate +
        "/" +
        this.OutletPartyId;
      this.dtOptions = {
        ajax: dataUrl,
        columns: [
          { title: "Date", data: "OutwardDate" },
          { title: "Outlet", data: "Outlet" },
          { title: "OutwardNumber", data: "OutwardNumber" },
          { title: "Category", data: "Category" },
          { title: "SubCategory", data: "SubCategory" },
          { title: "Series", data: "Series" },
          { title: "Article", data: "ArticleNumber" },
          { title: "Party", data: "PartyName" },
          { title: "Qty", data: "Quantity" },
          { title: "Rate", data: "Rate" },
          { title: "BillAmount", data: "BillAmount" },
          { title: "Discount", data: "Discount" },
          { title: "Remarks", data: "Remarks" },
          { title: "Country", data: "Country" },
          { title: "State", data: "State" },
          { title: "City", data: "City" },
          { title: "PinCode", data: "PinCode" },
          { title: "SalesPerson", data: "SalesPerson" },
        ],
        dom: "lBfrtip",
        buttons: [
          {
            extend: "copy",
            className: "reportbutton",
            title:
              "Colorhunt " + data.rangestartdate + " To " + data.rangeenddate,
          },
          {
            extend: "print",
            className: "reportbutton",
            title:
              "Colorhunt " + data.rangestartdate + " To " + data.rangeenddate,
          },
          {
            extend: "excel",
            className: "reportbutton",
            title:
              "Colorhunt " + data.rangestartdate + " To " + data.rangeenddate,
          },
        ],
        lengthMenu: [
          [10, 25, 50, -1],
          [10, 25, 50, "All"],
        ],
      };
    } else {
      const dataUrl =
        this.ApiURL +
        "/outwardreportlist/" +
        data.rangestartdate +
        "/" +
        data.rangeenddate;
      this.dtOptions = {
        ajax: dataUrl,
        columns: [
          // { title: "No", data: "Series" },
          { title: "Date", data: "OutwardDate" },
          { title: "Outlet", data: "Outlet" },
          { title: "OutwardNumber", data: "OutwardNumber" },
          { title: "SoNumber", data: "SoNumber" },
          { title: "Category", data: "Category" },
          { title: "SubCategory", data: "SubCategory" },
          { title: "Series", data: "Series" },
          { title: "Article", data: "ArticleNumber" },
          { title: "Party", data: "PartyName" },
          { title: "Qty", data: "Quantity" },
          { title: "Rate", data: "Rate" },
          { title: "BillAmount", data: "BillAmount" },
          { data: "Discount" },
          { title: "Remarks", data: "Remarks" },
          { title: "Country", data: "Country" },
          { title: "State", data: "State" },
          { title: "City", data: "City" },
          { title: "PinCode", data: "PinCode" },
          { title: "SalesPerson", data: "SalesPerson" },
        ],
        dom: "lBfrtip",
        buttons: [
          {
            extend: "copy",
            className: "reportbutton",
            title:
              "Colorhunt " + data.rangestartdate + " To " + data.rangeenddate,
          },
          {
            extend: "print",
            className: "reportbutton",
            title:
              "Colorhunt " + data.rangestartdate + " To " + data.rangeenddate,
          },
          {
            extend: "excel",
            className: "reportbutton",
            title:
              "Colorhunt " + data.rangestartdate + " To " + data.rangeenddate,
          },
        ],
        lengthMenu: [
          [10, 25, 50, -1],
          [10, 25, 50, "All"],
        ],
      };
    }
  }

  rightscheck(data, no) {
    let item = JSON.parse(localStorage.getItem("userdata"));

    if (no == 1) {
      var Count = Object.keys(data).length;
      for (let i = 0; i < Count; i++) {
        if (data[i].PageId == 4) {
          if (data[i].ListRights == 1) {
            this.accessdenied = false;
          } else {
            this.accessdenied = true;
          }
          this.isList = data[i].ListRights;
          this.isAdd = data[i].AddRights;
          this.isEdit = data[i].EditRights;
          this.isDelete = data[i].DeleteRights;
          break;
        } else {
          this.accessdenied = true;
        }
      }
    } else {
      for (let i = 0; i < data.length; i++) {
        if (data[i].PageId == 4) {
          if (data[i].ListRights == 1) {
            this.accessdenied = false;
          } else {
            this.accessdenied = true;
          }
          this.isList = data[i].ListRights;
          this.isAdd = data[i].AddRights;
          this.isEdit = data[i].EditRights;
          this.isDelete = data[i].DeleteRights;
          break;
        } else {
          this.accessdenied = true;
        }
      }
    }
  }
  ngAfterViewInit(): void {
    this.dtElement.dtInstance.then((dtInstance: DataTables.Api) => {
      dtInstance.on("draw.dt", function () {
        if ($(".dataTables_empty").length > 0) {
          $(".dataTables_empty").remove();
        }
      });
    });
  }
  ngOnDestroy(): void {
    // Do not forget to unsubscribe the event
    this.dtTrigger.unsubscribe();
  }
  // exportOutwardReport() {
  //   this.userService
  //     .getOutwardReport({
  //       RangeStartDate: this.outwardForm.value.rangestartdate,
  //       RangeEndDate: this.outwardForm.value.rangeenddate,
  //       OutletRec: this.outwardForm.value.SelectedOutlet,
  //     })
  //     .subscribe((res) => {
  //       this.allExportRec = res;
  //       const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(this.allExportRec, {
  //         header: [
  //           "Outlet",
  //           "OutwardNumber",
  //           "SoNumber",
  //           "Category",
  //           "SubCategory",
  //           "Series",
  //           "ArticleNumber",
  //           "PartyName",
  //           "NoPacks",
  //           "Quantity",
  //           "Rate",
  //           "BillAmount",
  //           "Discount",
  //           "Remarks",
  //           "Country",
  //           "State",
  //           "City",
  //           "PinCode",
  //           "SalesPerson",
  //         ],
  //       });
  //       var wscols = [
  //         { width: 11.0 },
  //         { width: 16.0 },
  //         { width: 19.0 },
  //         { width: 14.0 },
  //         { width: 22.0 },
  //         { width: 23.0 },
  //         { width: 30.0 },
  //         { width: 25.0 },
  //         { width: 15.0 },
  //         { width: 8.0 },
  //         { width: 4.0 },

  //         { width: 11.0 },
  //         { width: 8.0 },
  //         { width: 19.0 },
  //         { width: 8.0 },
  //         { width: 18.0 },
  //         { width: 17.0 },
  //         { width: 8.0 },
  //         { width: 17.0 },
  //       ];
  //       ws["!cols"] = wscols;
  //       const wb: XLSX.WorkBook = XLSX.utils.book_new();
  //       XLSX.utils.book_append_sheet(
  //         wb,
  //         ws,
  //         `${this.outwardForm.value.rangestartdate}-to-${this.outwardForm.value.rangeenddate}`
  //       );
  //       XLSX.writeFile(wb, "OutwardReport.xlsx");
  //     });
  // }
}
